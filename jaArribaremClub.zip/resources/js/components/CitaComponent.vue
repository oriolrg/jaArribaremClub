<template>
    <!-- ======= Cta Section ======= -->
    <section id="cta" class="cta">
        <div class="container">

        <div class="text-center" data-aos="zoom-in">
            <h3></h3>
            <p> </p>

        </div>

        </div>
    </section><!-- End Cta Section -->
</template>
    
<script>
        export default {
            mounted() {
                console.log('Caminada mounted.')
            }
        }
    </script>
    <style>
    .about{
      color: black;
    }
</style>
    