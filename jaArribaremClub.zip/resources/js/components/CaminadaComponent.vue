<template>
<div>
    <section id="caminada" class="team">
      <div class="container">

        <div class="row">
          <div class="col-lg-12">
            <div class="section-title content" data-aos="fade-right">
              <h2>{{results.nom}}</h2>
              <div class="member sortida">
                <div class="pic">
                  <img :src="'/'+results.imatges_id" class="img-fluid" :alt="results.nom">
                </div>
                <div class="member-info">
                  <h4>Sortida</h4>
                  <span>{{results.controls[0].nom}}</span>
                  <p>{{results.controls[0].descripcio}}</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-12">
            <div class="row">
              
              <div  v-for="(result, key, index) in results.controls.slice(1)" v-if="key < numControls -1" class="col-lg-6">
                <div class="member" data-aos="zoom-in" data-aos-delay="100">
                  <div class="pic"><img src="assets/img/team/team-1.jpg" class="img-fluid" alt=""></div>
                  <div class="member-info">
                    <h4>Control {{key+1}}</h4>
                    <h6>{{result.nom}}</h6>
                    <p>{{result.descripcio}}</p>
                  </div>
                </div>
              </div>
              <div class="member">
                <div class="pic"><img src="assets/img/team/team-1.jpg" class="img-fluid" alt=""></div>
                <div class="member-info" data-aos="zoom-in" data-aos-delay="500">
                  <h4>Arribada </h4>
                  <h6>{{results.controls[numControls].nom}}</h6>
                  <p>{{results.controls[numControls].descripcio}}</p>
                </div>
              </div>

            </div>

          </div>
          <div class="container">
            <div class="row">
              <div class="col-sm">
                <img :src="'/'+results.mapa_id" class="img-fluid" alt="Mapa">
              </div>
              <div class="col-sm">
                <img :src="'/'+results.altimetria_id" class="img-fluid" alt="Altimetria">
              </div>
            </div>
            <div class="row">

              <div class="col-sm" style="text-align: center;">
                <a :href="'/'+results.triptic_id" ><i class="bi bi-file-earmark-pdf-fill" style="font-size: 4em; "></i>Descarrega Triptic PDF</a>
                </div>
                <div class="col-sm" style="text-align: center;">
                  <a :href="'/'+results.track_id"><i class="fs bi-strava" style="font-size: 4em; "></i>Descarrega Track GPX</a>
                </div>
            </div>
          </div>  
        </div>

      </div>
    </section><!-- End Team Section -->
  </div>
</template>


<script>
    export default {
      data(){
            return {
                results: [],
                counter: 0,
                numControls: 0,
            }
        },
      components: {
      },
      beforeMount(){
          axios.get('/api/caminada/actual').then(response => {
            this.results = response.data;
            this.numControls = response.data.controls.length - 1

            console.log(response.data);
          });
        },
      mounted() {
          console.log('Caminada mounted.')
      }
    }
</script>
<style>
.about{
  color: black;
}
</style>
