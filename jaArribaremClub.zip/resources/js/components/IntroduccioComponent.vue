<template>
    <div><!-- ======= About Section ======= -->
        <section class="about">
          <div class="container">
    
            <div class="row content">
              <div class="col-lg-6" data-aos="fade-right" data-aos-delay="100">
                <h2>QUÈ ÉS LA CAMINADA POPULAR?</h2>
                <h3></h3>
              </div>
              <div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-left" data-aos-delay="200">
                <p>
                  És un intent de poder mostrar els entorns de la Vall de Lord; la fauna i la flora que hi conviuen, els monuments i els llocs més pintorescos i amagats. I la que la millor manera de endinsar-te a la natura és caminant de forma pausada, sense motors ni cap mena de soroll que molesti.
    Gairebé en totes les edicions de la Caminada s’ha intentat mostrar vells oficis o activitats que abans eren habituals a la Vall de Lord. Gràcies a la Caminada, es recuperen molts camins i fonts que el temps havia deixat en desús.
                </p>
                <p>La sortida de la Caminada varia cada any en funció de d’itinerari escollit. S’aconsella visitar periòdicament aquesta pàgina web per conèixer els detalls de cada edició. Per donar més varietat als recorreguts, intentem que la Caminada surti des de els tres municipis de la Vall de Lord: </p>
                <ul>
                  <li><i class="ri-check-double-line"></i> Guixers</li>
                  <li><i class="ri-check-double-line"></i> La Coma i la Pedra</li>
                  <li><i class="ri-check-double-line"></i> Sant Llorenç de Morunys</li>
                </ul>
              </div>
            </div>
          </div>
        </section><!-- End About Section -->
      </div>
    </template>
    
    
    <script>
        export default {
          data(){
                return {
                    results: [],
                    counter: 0,
                    numControls: 0,
                }
            },
          components: {
          },
          beforeMount(){
            },
          mounted() {
              console.log('Caminada mounted.')
          }
        }
    </script>
    <style>
    .about{
      color: black;
    }
    </style>
    