<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();



Route::get('/caminades/buscar', 'App\Http\Controllers\CaminadaController@show');
Route::get('/caminada/{numeroCaminada}', function ($numeroCaminada) {
    return view('caminada');
});
Route::group(['prefix'=>'home','as'=>'home.'], function(){
    Route::group(['prefix'=>'colaboradors','as'=>'colaboradors.'], function(){

        Route::get('/', 'App\Http\Controllers\ColaboradorController@list')->name('colaboradorsLlista');

        Route::post('/nou', 'App\Http\Controllers\ColaboradorController@store')->name('colaboradorsNou');

        Route::get('/nou', 'App\Http\Controllers\ColaboradorController@new')->name('colaboradorsNou');

        Route::get('/editar/{id}', 'App\Http\Controllers\ColaboradorController@edit')->name('colaboradorsEditar');

        Route::put('/actualizar/{id}', 'App\Http\Controllers\ColaboradorController@update')->name('colaboradorsActualitzar');

        Route::delete('/borrar/{id}', 'App\Http\Controllers\ColaboradorController@destroy')->name('colaboradorsBorrar');

    });
    Route::group(['prefix'=>'caminades','as'=>'caminades.'], function(){

        Route::get('/', 'App\Http\Controllers\CaminadaController@index');

        Route::post('/nou', 'App\Http\Controllers\CaminadaController@store')->name('caminadaNou');

        Route::get('/nou', 'App\Http\Controllers\CaminadaController@new');

        Route::get('/editar/{id}', 'App\Http\Controllers\CaminadaController@edit')->name('caminadesEditar');

        Route::put('/actualizar/{id}', 'App\Http\Controllers\CaminadaController@update')->name('caminadesActualitzar');

        Route::delete('/borrar/{id}', 'App\Http\Controllers\CaminadaController@destroy')->name('caminadesBorrar');


    });

    Route::get('/', [App\Http\Controllers\CaminadaController::class, 'index'])->name('home');

});