<table>
    <tbody>
        <tr>
        <td>
                <label for="description">Nom</label>
                <textarea type="text" name="nom" id="nom" class="form-control" placeholder="Descripció..." rows="6"><?php if(isset($missatge)): ?> <?php echo e($missatge->missatge); ?> <?php endif; ?></textarea>
            </td>
            <td>
                <label for="description">Descripcio</label>
                <textarea type="text" name="descripcio" id="descripcio" class="form-control" placeholder="Descripció..." rows="6"><?php if(isset($missatge)): ?> <?php echo e($missatge->missatge); ?> <?php endif; ?></textarea>
            </td>
            <td>
                <label for="description">Url web</label>
                <textarea type="text" name="url" id="desurlcripcio" class="form-control" placeholder="Descripció..." rows="6"><?php if(isset($missatge)): ?> <?php echo e($missatge->missatge); ?> <?php endif; ?></textarea>
            </td>
            <td>
                <label for="description">Imatge</label>
                <textarea type="text" name="imatge" id="imatge" class="form-control" placeholder="Descripció..." rows="6"><?php if(isset($missatge)): ?> <?php echo e($missatge->missatge); ?> <?php endif; ?></textarea>
            </td>
            <!--<td>
                <label for="description">Descripcio</label>
                <textarea type="text" name="descripcioES" id="descripcio" class="form-control" placeholder="Descripció..." rows="6"><?php if(isset($missatge)): ?> <?php echo e($missatge->missatgeES); ?> <?php endif; ?></textarea>
            </td>
            <td>
                <label for="description">Descripcio</label>
                <textarea type="text" name="descripcioEN" id="descripcio" class="form-control" placeholder="Descripció..." rows="6"><?php if(isset($missatge)): ?> <?php echo e($missatge->missatgeEN); ?> <?php endif; ?></textarea>
            </td>-->
        </tr>
    </tbody>
</table>

<?php /**PATH /home/oriol/Documents/tecnolord/jaarribaremaclub/webCaminada/resources/views/administra/colaboradors/form/missatge_form_edita.blade.php ENDPATH**/ ?>