
<div class="col-lg-12">
    <label for="description">Nom</label>
    <input type="text" name="nom" id="nom" class="form-control" placeholder="Nom..." value="<?php echo e(isset($editdata) ? $editdata->nom : ''); ?>"  maxlength="60">
</div>

<div class="col-lg-12">
    <label for="description">Descripcio</label>
    <input type="text" name="descripcio" id="descripcio" class="form-control" placeholder="Descripcio..." value="<?php echo e(isset($editdata) ? $editdata->descripcio : ''); ?>"  maxlength="60">
</div>

<div class="col-lg-12">
    <label for="description">Url web</label>
    <input type="text" name="url" id="url" class="form-control" placeholder="Url..." value="<?php echo e(isset($editdata) ? $editdata->url : ''); ?>"  maxlength="60">
</div>

<?php if(!isset($editdata->imatges_id)): ?>
    <div class="col-lg-12">
        <label for="title">Imatge General</label>
        <input type="file" name="imatge" id="imatge" class="form-control" placeholder="Titol..." value="<?php echo e(isset($editdata) ? $editdata->titol : ''); ?>"  maxlength="30">
    </div>
<?php endif; ?>
<?php /**PATH /home/oriol/Documents/tecnolord/jaarribaremaclub/webCaminada/resources/views/administra/colaboradors/form/colaboradors_form_edita.blade.php ENDPATH**/ ?>