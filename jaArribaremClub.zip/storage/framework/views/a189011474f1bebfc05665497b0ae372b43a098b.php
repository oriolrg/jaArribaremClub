
<div class="col-lg-12">
    <label for="description">Nom</label>
    <input type="text" name="nom" id="nom" class="form-control" placeholder="Nom..." value="<?php echo e(isset($editdata) ? $editdata->nom : ''); ?>"  maxlength="60">
</div>
<div class="col-lg-12">
    <label for="description">Descripció</label>
    <input type="text" name="descripcio" id="descripcio" class="form-control" placeholder="Descripcio..." value="<?php echo e(isset($editdata) ? $editdata->descripcio : ''); ?>"  maxlength="60">
</div>
<div class="col-lg-12">
    <label for="description">Data de la caminada</label>
    <input type="text" name="data" id="data" class="form-control" placeholder="22-04-18..." value="<?php echo e(isset($editdata) ? $editdata->data : ''); ?>"  maxlength="60">
</div>
<div class="col-lg-12">
    <label for="description">Controls</label>
    <label for="description">Sortida</label>
    <div class="col-lg-12">
        <label for="description">Nom</label>
        <input class="form-control" name="nom_sortida" type="text"/>
        <label for="description">Descripció</label>
        <input class="form-control" name="descripcio_sortida'" type="text"/>
    </div>
    <div class="row">
        <button id="addControl()" onClick="addControl()" type="button" class="btn btn-info">Afegir Control</button>
    </div>
    
    <div class="row" id="controls"></div>
    <label for="description">Arribada</label>
    <div class="col-lg-12">

        <label for="description">Nom</label>
        <input class="form-control" name="nom_arribada" type="text"/>    
        <label for="description">Descripció</label>
        <input class="form-control" name="descripcio_'arribada'" type="text"/>
        <label for="description">Distancia acumulada</label>
        <input class="form-control" name="distancia_acumulada_arribada'" type="text"/>
    </div>
</div>

<?php if(!isset($editdata->imatges_id)): ?>
    <div class="col-lg-12">
        <label for="title">Imatge Portada</label>
        <input type="file" name="imatge" id="imatge" class="form-control" placeholder="Titol..." value="<?php echo e(isset($editdata) ? $editdata->titol : ''); ?>"  maxlength="30">
    </div>
<?php endif; ?>
<?php if(!isset($editdata->imatges_id)): ?>
    <div class="col-lg-12">
        <label for="title">Imatge Altimetria</label>
        <input type="file" name="altimetria" id="altimetria" class="form-control" placeholder="Titol..." value="<?php echo e(isset($editdata) ? $editdata->titol : ''); ?>"  maxlength="30">
    </div>
<?php endif; ?>
<?php if(!isset($editdata->imatges_id)): ?>
    <div class="col-lg-12">
        <label for="title">Imatge Mapa</label>
        <input type="file" name="mapa" id="mapa" class="form-control" placeholder="Titol..." value="<?php echo e(isset($editdata) ? $editdata->titol : ''); ?>"  maxlength="30">
    </div>
<?php endif; ?>
<?php if(!isset($editdata->imatges_id)): ?>
    <div class="col-lg-12">
        <label for="title">Track</label>
        <input type="file" name="track" id="track" class="form-control" placeholder="Titol..." value="<?php echo e(isset($editdata) ? $editdata->titol : ''); ?>"  maxlength="30">
    </div>
<?php endif; ?>
<?php if(!isset($editdata->imatges_id)): ?>
    <div class="col-lg-12">
        <label for="title">Triptic</label>
        <input type="file" name="triptic" id="triptic" class="form-control" placeholder="Titol..." value="<?php echo e(isset($editdata) ? $editdata->titol : ''); ?>"  maxlength="30">
    </div>
<?php endif; ?>
<script>
a = 0;
function addControl(){
        a++;

        var div = document.createElement('div');
        div.setAttribute('class', 'form-inline');
        div.innerHTML = 
            '<label for="description">Control '+a+'</label>'+
            '<div class="col-lg-12">'+
                '<label for="description">Nom</label>'+
                '<input class="form-control" name="control['+a+'][nom]" type="text"/>'+
                '<label for="description">Descripcio</label>'+
                '<input class="form-control" name="control['+a+'][descripcio]" type="text"/>'+
                '<label for="description">Distancia acumulada</label>'+
                '<input class="form-control" name="control['+a+'][distancia]" type="text"/>'+
            '</div>';
        document.getElementById('controls').appendChild(div);document.getElementById('controls').appendChild(div);
}
</script><?php /**PATH /home/oriol/Documents/tecnolord/jaarribaremaclub/webCaminada/resources/views/administra/caminades/form/missatge_form_edita.blade.php ENDPATH**/ ?>