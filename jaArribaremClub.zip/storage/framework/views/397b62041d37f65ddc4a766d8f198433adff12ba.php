<table>
    <thead>
        <tr>
            <th>Català</th>
            <th>Castellà</th>
            <th>Anglès</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>
                <label for="description">Descripcio</label>
                <textarea type="text" name="descripcio" id="descripcio" class="form-control" placeholder="Descripció..." rows="6"><?php if(isset($missatge)): ?> <?php echo e($missatge->missatge); ?> <?php endif; ?></textarea>
            </td>
            <td>
                <label for="description">Descripcio</label>
                <textarea type="text" name="descripcioES" id="descripcio" class="form-control" placeholder="Descripció..." rows="6"><?php if(isset($missatge)): ?> <?php echo e($missatge->missatgeES); ?> <?php endif; ?></textarea>
            </td>
            <td>
                <label for="description">Descripcio</label>
                <textarea type="text" name="descripcioEN" id="descripcio" class="form-control" placeholder="Descripció..." rows="6"><?php if(isset($missatge)): ?> <?php echo e($missatge->missatgeEN); ?> <?php endif; ?></textarea>
            </td>
        </tr>
    </tbody>
</table>

<?php /**PATH /home/oriol/Documents/tecnolord/jaarribaremaclub/webCaminada/resources/views/administra/form/missatge_form_edita.blade.php ENDPATH**/ ?>