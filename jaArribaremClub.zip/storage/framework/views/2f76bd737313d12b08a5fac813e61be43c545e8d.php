    <?php $__env->startSection('content'); ?>
        <div id="app" class="content"><!--La equita id debe ser app, como hemos visto en app.js-->
            <main id="main">
                <caminada-component></caminada-component>
                <caminades-anteriors-component></caminades-anteriors-component>
                <com-arribar-component></com-arribar-component>
                <colaboradors-component></colaboradors-component>
            </main>
            <footer-component></footer-component>
        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oriol/Documents/tecnolord/jaarribaremaclub/webCaminada/resources/views/caminada.blade.php ENDPATH**/ ?>