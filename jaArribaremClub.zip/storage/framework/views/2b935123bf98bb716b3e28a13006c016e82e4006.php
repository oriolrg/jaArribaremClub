    <?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row flex-nowrap">
            <?php echo $__env->make('administra.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col py-3"><!--La equita id debe ser app, como hemos visto en app.js-->
                <div class="container">
                    <?php if(!isset($editdata)): ?>
                        <form action="<?php echo e(URL::to('home/caminades/nou')); ?>" method="POST"  enctype="multipart/form-data">
                    <?php endif; ?>
                    <?php if(isset($editdata)): ?>
                        <form action="<?php echo e(URL::to('home/caminades/actualizar')); ?>/<?php echo e($editdata->id); ?>" method="POST"  enctype="multipart/form-data">
                        <?php echo e(method_field('PUT')); ?>

                    <?php endif; ?>
                        <?php echo csrf_field(); ?>
                        <h2>Edita Caminada</h2>
                        <?php echo $__env->make('administra.caminades.form.caminada_form_edita', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <button type="submit" class="btn btn-primary" >
                            <i class="glyphicon glyphicon-send"> Enviar </i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
        
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oriol/Documents/tecnolord/jaarribaremaclub/webCaminada/resources/views/administra/caminades/home.blade.php ENDPATH**/ ?>