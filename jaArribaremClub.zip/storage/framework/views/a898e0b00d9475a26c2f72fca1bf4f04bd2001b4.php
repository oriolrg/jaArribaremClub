   
    <?php $__env->startSection('content'); ?>
        <!-- Page Content Holder -->
        <div id="content">
            <h2>Llistat de reserves</h2>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <!--<div class="container-fluid">

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="nav navbar-nav ml-auto">
                            <li class="nav-item active">
                                <a class="nav-link" href="#">Page</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Page</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Page</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Page</a>
                            </li>
                        </ul>
                    </div>
                </div>-->
            </nav>
            <h2>
                Reserves d'avui
                <a class="btn btn-small btn-success" href="<?php echo e(URL::to('administra/reservaAvui/create')); ?>">
                    <span class="plus">+ </span><strong>Nova Reserva</strong>
                </a>
            </h2>
            <label for="preu">Escull la data que vols consultar</label>
            <script>
                $(".form-control").change(function () {
                    //WEBTESTwindow.location.replace("/venda-entrades2/administra/reserva/" + $(".form-control").val());
                    window.location.replace("/venda-entrades/administra/reserva/" + $(".form-control").val());
                })
            </script>
            <?php if(Session::has('message')): ?>
                <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
            <?php endif; ?>
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <td>Sessio</td>
                        <td>Aforament disponible</td>
                        <td>Places reservades</td>
                        <td>Hora</td>
                    </tr>
                </thead>
                <tbody>
                <?php if(@isset($data)): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $reserva_sessio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($reserva_sessio->nom); ?></td>
                            <td><?php echo e($reserva_sessio->aforament_disponible); ?></td>
                            <td><?php echo e($reserva_sessio->aforament); ?></td>
                            <td><?php echo e($reserva_sessio->hora); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <td>Email</td>
                        <td>Telèfon</td>
                        <td>Accio</td>
                    </tr>
                </thead>
                <tbody>
                <?php if(@isset($entrades)): ?>
                    <?php $__currentLoopData = $entrades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($entrada->comprador->email); ?></td>
                                <td><?php echo e($entrada->comprador->telefon); ?></td>
                                <td><a href="<?php echo e(URL::to('administra/reservaConsulta/')); ?>/<?php echo e($entrada->comprador->id); ?>" type="button" class="btn btn-primary">Consultar reserva</a></td>
                            </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('administra.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('administra.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oriol/Documents/tecnolord/jaarribaremaclub/webCaminada/resources/views/administra/home.blade.php ENDPATH**/ ?>