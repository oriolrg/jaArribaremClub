    <?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row flex-nowrap">
            <?php echo $__env->make('administra.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col py-3"><!--La equita id debe ser app, como hemos visto en app.js-->
                <div class="container">
                        <h2>Col·laboradors</h2> 
                        <a href="colaboradors/nou" class="btn btn-success col-12" >
                            <b><i class="bi bi-patch-plus"> Nou Col·laborador</i></b>
                        </a>
                        <ul class="list-group cProductsList"> 
                            <?php $__currentLoopData = $colaboradors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-sm">
                                            <p class="p-0 m-0 flex-grow-1"><?php echo e($data->nom); ?></p>
                                        </div>
                                        <div class="col-sm">
                                            <img src="/<?php echo e($data->img); ?>" alt="<?php echo e($data->nom); ?>" width="80" height="80"/> 
                                        </div>
                                        <div class="col-sm">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm">
                                                        <a href="<?php echo e(route('home.colaboradors.colaboradorsEditar', $data->id)); ?>" class="btn btn-primary col-sm" >
                                                            <i class="bi bi-gear-wide"> Editar </i>
                                                        </a>
                                                    </div>
                                                    <div class="col-sm">
                                                        <form action="<?php echo e(route('home.colaboradors.colaboradorsBorrar', $data->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button class="btn btn-danger col-sm" title="Delete"><i class="bi bi-eraser"> Borrar </i></button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div></div>
                                
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                </div>
            </div>
        </div>
    </div>
        
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oriol/Documents/tecnolord/jaarribaremaclub/webCaminada/resources/views/administra/colaboradors/list.blade.php ENDPATH**/ ?>