    <?php $__env->startSection('content'); ?>
        <div id="app" class="content"><!--La equita id debe ser app, como hemos visto en app.js-->
            
        </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oriol/Documents/tecnolord/jaarribaremaclub/webCaminada/resources/views/home.blade.php ENDPATH**/ ?>