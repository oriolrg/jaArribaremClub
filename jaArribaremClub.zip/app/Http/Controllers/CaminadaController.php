<?php

namespace App\Http\Controllers;

use App\Models\Caminada;
use App\Models\Controls;
use App\Models\FileUpload;
use Illuminate\Http\Request;

class CaminadaController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $caminada = Caminada::orderBy('caminada_numero', 'desc')->get();
        /*foreach ($colaborador as $key => $value) {
            $value->img = File::findOrFail($value->imatges_id)->path;
        }*/
        return view('administra.caminades.list')->with("caminades",$caminada);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function new()
    {
        return view('administra.caminades.home');
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Caminada  $caminada
     * @return \Illuminate\Http\Response
     */
    public function edit(Caminada $colaboradors, $id)
    {
        $caminada = Caminada::findOrFail($id);
        //return $caminada;
        $caminada->controls = $caminada->controls()->get();
        //return $caminada;
        return view('administra.caminades.home')->with("editdata",$caminada);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //'nom', 'descripcio', 'data_caminada','participants','caminada_numero','poblacio', 'direccio_inici', 'coordenades_inici', 'track_id', 'imatges_id','mapa_id', 'altimetria_id', 'triptic_id'];
        //return $request->file('altimetria');
        $caminada = new Caminada();
        $caminada->nom = $request->nom;
        $caminada->descripcio = $request->descripcio;
        $caminada->data_caminada = $request->data;
        $caminada->participants = $request->participants;
        $caminada->caminada_numero = $request->caminada_numero;
        $caminada->poblacio = $request->poblacio;
        $caminada->direccio_inici = $request->direccio_inici;
        $caminada->latitud = $request->latitud;
        $caminada->longitud = $request->longitud;

        if($request->file('imatge')){
            $request['carpeta'] = "portada_caminada";
            $image = $request->file('imatge');
            $destinationPath = 'images/'.$request->carpeta.'/';
            $profileImage = $request->nom.'.'. $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $input['image'] = "$destinationPath$profileImage";
            $imatge = new FileUpload();
            $imatge->path = $input['image'];
            $imatge->save();
            $caminada->imatges_id = $imatge['id'];
        }
        if($request->file('altimetria')){
            $request['carpeta'] = "altimetria";
            $image = $request->file('altimetria');
            $destinationPath = 'images/'.$request->carpeta.'/';
            $profileImage = $request->nom.'.'. $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $input['image'] = "$destinationPath$profileImage";
            $imatge = new FileUpload();
            $imatge->path = $input['image'];
            $imatge->save();
            $caminada->altimetria_id = $imatge['id'];
        }
        if($request->file('triptic')){
            $request['carpeta'] = "triptics";
            $image = $request->file('triptic');
            $destinationPath = 'images/'.$request->carpeta.'/';
            $profileImage = $request->nom.'.'. $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $input['image'] = "$destinationPath$profileImage";
            $imatge = new FileUpload();
            $imatge->path = $input['image'];
            $imatge->save();
            $caminada->triptic_id = $imatge['id'];
        }
        if($request->file('mapa')){
            $request['carpeta'] = "mapes";
            $image = $request->file('mapa');
            $destinationPath = 'images/'.$request->carpeta.'/';
            $profileImage = $request->nom.'.'. $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $input['image'] = "$destinationPath$profileImage";
            $imatge = new FileUpload();
            $imatge->path = $input['image'];
            $imatge->save();
            $caminada->mapa_id = $imatge['id'];
            //$caminada->imatges_id = $imatgePortada;
        }
        if($request->file('track')){
            $request['carpeta'] = "tracks";
            $image = $request->file('track');
            $destinationPath = 'images/'.$request->carpeta.'/';
            $profileImage = $request->nom.'.'. $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $input['image'] = "$destinationPath$profileImage";
            $imatge = new FileUpload();
            $imatge->path = $input['image'];
            $imatge->save();
            $caminada->track_id = $imatge['id'];
            //$caminada->imatges_id = $imatgePortada;
        }
        $caminada->save();
        //$control = new Controls() ;
        //$control->nom = $request->nom_sortida;
        //$control->descripcio = $request->descripcio_sortida;  
        //$control->coordenades = $request->coordenades_inici;  
        //$caminada->controls()->save($control);
        if($request->control){
            foreach ($request->control as $key => $value) {
                $control = new Controls();
                $control->nom = $value['nom'];
                $control->descripcio = $value['descripcio'];  
                $control->distancia = $value['distancia']; 
                $control->latitud = $value['latitud'];  
                $control->longitud = $value['longitud'];  
                $caminada->controls()->save($control);
            }
        }
        

        //$control = new Controls() ;
        //$control->nom = $request->nom_arribada;
        //$control->descripcio = $request->descripcio_arribada;  
        //$control->distancia = $request->distancia_acumulada_arribada; 
        //$control->latitud = $request->latitud;  
        //$control->longitud = $request->longitud;  
        //$caminada->controls()->save($control);

        $caminada->save();
        return redirect('/home/caminades');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Caminada  $caminada
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        $caminada = Caminada::findOrFail($request->id);
        return $caminada;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Caminada  $caminada
     * @return \Illuminate\Http\Response
     */
    public function update($id,Request $request, Caminada $caminada)
    {
        //return $request;
        //TODO queda realitzar l'actualitzacio
        $caminada =  Caminada::findOrFail($id);
        $caminada->nom = $request->nom;
        $caminada->descripcio = $request->descripcio;
        $caminada->data_caminada = $request->data;
        $caminada->participants = $request->participants;
        $caminada->caminada_numero = $request->caminada_numero;
        $caminada->poblacio = $request->poblacio;
        $caminada->direccio_inici = $request->direccio_inici;
        $caminada->latitud = $request->latitud;
        $caminada->longitud = $request->longitud;

        if($request->file('imatge')){
            $request['carpeta'] = "portada_caminada";
            $image = $request->file('imatge');
            $destinationPath = 'images/'.$request->carpeta.'/';
            $profileImage = $request->nom.'.'. $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $input['image'] = "$destinationPath$profileImage";
            $imatge = new FileUpload();
            $imatge->path = $input['image'];
            $imatge->save();
            $caminada->imatges_id = $imatge['id'];
        }
        if($request->file('altimetria')){
            $request['carpeta'] = "altimetria";
            $image = $request->file('altimetria');
            $destinationPath = 'images/'.$request->carpeta.'/';
            $profileImage = $request->nom.'.'. $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $input['image'] = "$destinationPath$profileImage";
            $imatge = new FileUpload();
            $imatge->path = $input['image'];
            $imatge->save();
            $caminada->altimetria_id = $imatge['id'];
        }
        if($request->file('triptic')){
            $request['carpeta'] = "triptics";
            $image = $request->file('triptic');
            $destinationPath = 'images/'.$request->carpeta.'/';
            $profileImage = $request->nom.'.'. $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $input['image'] = "$destinationPath$profileImage";
            $imatge = new FileUpload();
            $imatge->path = $input['image'];
            $imatge->save();
            $caminada->triptic_id = $imatge['id'];
        }
        if($request->file('mapa')){
            $request['carpeta'] = "mapes";
            $image = $request->file('mapa');
            $destinationPath = 'images/'.$request->carpeta.'/';
            $profileImage = $request->nom.'.'. $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $input['image'] = "$destinationPath$profileImage";
            $imatge = new FileUpload();
            $imatge->path = $input['image'];
            $imatge->save();
            $caminada->mapa_id = $imatge['id'];
            //$caminada->imatges_id = $imatgePortada;
        }
        if($request->file('track')){
            $request['carpeta'] = "tracks";
            $image = $request->file('track');
            $destinationPath = 'images/'.$request->carpeta.'/';
            $profileImage = $request->nom.'.'. $image->getClientOriginalExtension();
            $image->move($destinationPath, $profileImage);
            $input['image'] = "$destinationPath$profileImage";
            $imatge = new FileUpload();
            $imatge->path = $input['image'];
            $imatge->save();
            $caminada->track_id = $imatge['id'];
            //$caminada->imatges_id = $imatgePortada;
        }
        $caminada->save();
        //$control = new Controls() ; 
        if($request->control){
            foreach ($request->control as $key => $value) {
                $control = Controls::findOrFail($key);
                $control->nom = $value['nom'];
                $control->descripcio = $value['descripcio'];  
                $control->distancia = $value['distancia']; 
                $control->latitud = $value['latitud'];  
                $control->longitud = $value['longitud'];  
                $caminada->controls()->update($control);
            }
        }
        

        //$control = new Controls() ;
        $caminada->save();


        return redirect('/home/caminades');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Caminada  $caminada
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $caminada = Caminada::findOrFail($request->id);
        $caminada->controls()->delete();
        $caminada->controls()->detach();
        $caminada->delete();

        //$controls = Controls::where('caminada_id',$request->id)->delete();
        return redirect('/home/caminades');
    }
}
